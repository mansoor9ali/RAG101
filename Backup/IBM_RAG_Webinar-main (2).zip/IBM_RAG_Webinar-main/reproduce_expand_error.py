import os
import sys
from dotenv import load_dotenv

# Load .env from project root
load_dotenv()

# Add backend directory to sys.path
sys.path.append(os.path.join(os.getcwd(), 'webinar_app/backend'))

try:
    from rag_core import expand_query

    print("Successfully imported expand_query")
    
    query = "What is instruction tuning?"

    print(f"Testing expansion with query: {query}")
    
    expanded = expand_query(query)
    
    print("Expansion successful!")
    print(f"Expanded Queries: {expanded}")

except Exception as e:
    print(f"Error occurred: {e}")
    import traceback
    traceback.print_exc()
