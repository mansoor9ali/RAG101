import os
import sys

# Add backend directory to sys.path
sys.path.append(os.path.join(os.getcwd(), 'webinar_app/backend'))

try:
    from rag_core import rerank_documents
    from langchain_core.documents import Document

    print("Successfully imported rerank_documents")

    query = "What is instruction tuning?"
    docs = [
        Document(page_content="Instruction tuning is a method to finetune LLMs.", metadata={"source": "doc1"}),
        Document(page_content="Photosynthesis is a process in plants.", metadata={"source": "doc2"}),
        Document(page_content="Large language models are trained on vast data.", metadata={"source": "doc3"}),
    ]

    print("Attempting to rerank...")
    results = rerank_documents(query, docs, top_k=2)
    
    print("Reranking successful!")
    for doc, score in results:
        print(f"Score: {score:.4f} - Content: {doc.page_content}")

except Exception as e:
    print(f"Error occurred: {e}")
    import traceback
    traceback.print_exc()
