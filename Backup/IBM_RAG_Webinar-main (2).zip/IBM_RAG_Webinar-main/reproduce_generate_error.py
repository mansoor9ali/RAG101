import os
import sys
from dotenv import load_dotenv

# Load .env from project root
load_dotenv()

# Add backend directory to sys.path
sys.path.append(os.path.join(os.getcwd(), 'webinar_app/backend'))

try:
    from rag_core import generate_answer

    print("Successfully imported generate_answer")
    
    query = "What is instruction tuning?"
    context = ["Instruction tuning is a method to finetune LLMs.", "It improves performance on unseen tasks."]

    print(f"Testing generation with query: {query}")
    print(f"WATSONX_PROJECT_ID: {os.getenv('WATSONX_PROJECT_ID')}")
    
    answer = generate_answer(query, context)
    
    print("Generation successful!")
    print(f"Answer: {answer}")

except Exception as e:
    print(f"Error occurred: {e}")
    import traceback
    traceback.print_exc()
