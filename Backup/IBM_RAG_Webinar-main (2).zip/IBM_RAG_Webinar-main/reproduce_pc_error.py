import os
import sys
from dotenv import load_dotenv
from langchain_core.documents import Document

# Load .env from project root
load_dotenv()

# Add backend directory to sys.path
sys.path.append(os.path.join(os.getcwd(), 'webinar_app/backend'))

try:
    from rag_core import create_parent_child_index, retrieve_parent_child

    print("Successfully imported Parent-Child functions")
    
    docs = [
        Document(page_content="This is a long parent document about instruction tuning. " * 20, metadata={"source": "doc1"}),
        Document(page_content="This is another long parent document about photosynthesis. " * 20, metadata={"source": "doc2"}),
    ]

    print("Creating index...")
    collection_name = create_parent_child_index(docs)
    print(f"Index created: {collection_name}")
    
    query = "instruction tuning"
    print(f"Querying: {query}")
    
    parents, children = retrieve_parent_child(query, collection_name)
    
    print("Retrieval successful!")
    print(f"Parents: {len(parents)}")
    print(f"Children: {len(children)}")

except Exception as e:
    print(f"Error occurred: {e}")
    import traceback
    traceback.print_exc()
